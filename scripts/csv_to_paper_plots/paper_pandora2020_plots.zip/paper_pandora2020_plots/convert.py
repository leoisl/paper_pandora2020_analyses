from glob import glob
import subprocess

files = glob("*.png")
for file in files:
  command_line = f"convert {file} {file.replace('.png', '.pdf')}"
  print(command_line)
  subprocess.check_call(command_line, shell=True)
